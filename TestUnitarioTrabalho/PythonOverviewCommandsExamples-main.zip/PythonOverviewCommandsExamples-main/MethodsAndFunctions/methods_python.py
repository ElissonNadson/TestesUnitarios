my_list = [1, 2, 3]
my_list.append(4)
print(f"1: {my_list}")
my_list.pop()
print(f"2: {my_list}")
help(my_list.insert)
