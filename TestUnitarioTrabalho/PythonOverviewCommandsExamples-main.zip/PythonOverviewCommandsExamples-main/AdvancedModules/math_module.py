import math

value = 4.35
print(f"1: {math.floor(value)}")
print(f"2: {math.ceil(value)}")
print(f"3: {round(value)}")
print(f"4: {round(4.5)}")
print(f"5: {round(5.5)}")
print(f"6: {math.pi}")
print(f"7: {math.e}")
print(f"8: {math.inf}")
print(f"9: {math.nan}")
print(f"10: {math.log(math.e)}")
print(f"11: {math.log(100, 10)}")
print(f"12: {10**2}")
print(f"13: {math.sin(10)}")
print(f"14: {math.degrees(math.pi/2)}")
print(f"15: {math.radians(180)}")
