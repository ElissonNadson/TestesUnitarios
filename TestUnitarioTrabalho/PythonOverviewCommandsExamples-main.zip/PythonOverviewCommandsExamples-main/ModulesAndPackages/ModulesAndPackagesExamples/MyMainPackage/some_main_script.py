def report_main():
    print("Hey I am in some_main_sciprt in main package.")
