from myprogram import my_func

my_func()

from MyMainPackage import some_main_script
from MyMainPackage.SubPackage import my_sub_script

some_main_script.report_main()
my_sub_script.sub_report()
