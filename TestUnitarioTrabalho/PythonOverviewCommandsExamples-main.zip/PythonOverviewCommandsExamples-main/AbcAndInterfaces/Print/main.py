from print import Print

print = Print()
print.print_standard()
print.print_generic()
print.print_name("Elgin")