class DuckInterface:
    def __init__(self) -> None:
        pass

    def walk(self):
        pass

    def swin(self):
        pass

    def quack(self):
        pass
