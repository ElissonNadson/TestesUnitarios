import mock_examples.functions as functions

print(functions.double())
