from slow import api_call


def slow_function():
    api_result = api_call()
    return api_result
