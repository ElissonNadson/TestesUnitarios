from .constants import CONSTANT_A


def double():
    return CONSTANT_A * 2
