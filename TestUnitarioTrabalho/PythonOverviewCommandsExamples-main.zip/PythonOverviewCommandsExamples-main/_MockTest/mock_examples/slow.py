import time


def api_call():
    time.sleep(3)
    return 9
