input_str = input("Please enter a value: ")
print(f"1: {input_str}")
print(f"2: {type(input_str)}")

input_num = int(input("Ender value: "))
print(f"3: {input_num}")
print(f"4: {type(input_num)}")
