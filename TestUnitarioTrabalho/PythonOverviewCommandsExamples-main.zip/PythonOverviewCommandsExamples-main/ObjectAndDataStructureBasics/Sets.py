my_set = set()
print(f"1: {my_set}")
my_set.add(1)
print(f"2: {my_set}")
my_set.add(2)
print(f"3: {my_set}")
my_list = [1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3]
print(f"4: {set(my_list)}")
