class Person:
    def __init__(self, age) -> None:
        self.age = age
