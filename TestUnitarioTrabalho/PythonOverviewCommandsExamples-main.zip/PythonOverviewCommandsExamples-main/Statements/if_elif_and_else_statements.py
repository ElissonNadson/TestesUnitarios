if True:
    print("1: It's true!")

if 3 > 2:
    print("2: It's true!")

hungry = False
if hungry:
    print("Feed me!")
else:
    print("3: I'm not hungry.")


hungry = True
if hungry == True:
    print("4: Feed me!")
else:
    print("I'm not hungry.")

loc = "Game"

if loc == "Auto Shop":
    print("5: Cars are cool!")
elif loc == "Bank":
    print("5: Money are cool!")
elif loc == "Stoer":
    print("5: Welcome to the store!")
else:
    print("5: I don't know much.")

name = "Jefté"

if name == "Frankie":
    print("6: Hello Frankie!")
elif name == "Sammy":
    print("6: Hello Sammy!")
else:
    print("6: What's is your name?")
